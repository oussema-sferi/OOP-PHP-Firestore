var easyMDE = new EasyMDE({
    element: document.getElementById('postDistribution'),
    toolbar: ['bold', 'italic', 'heading','heading-1', 'heading-2', 'heading-3', '|', 'quote', 'unordered-list', 'ordered-list', '|', 'link', 'image', '|', 'preview']
});
